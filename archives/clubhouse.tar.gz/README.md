# Clubhouse recipe for Ferdi
This is a recipe to add Clubhouse to Ferdi

Clubhouse: https://clubhouse.io/
Ferdi: https://getferdi.com/
